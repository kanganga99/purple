
<?php
include "../config/db.php"; 
$id = $_GET['id'];
$sql ="DELETE FROM students WHERE id = $id";
$result = mysqli_query($conn, $sql);
if($result){
    header("Location: ./index.php?msg=Record deleted");
}
else{
    echo "Failed" . mysqli_error($con);
    
}
$query=mysqli_query($conn,"SELECT * FROM students");
$number=1;
while($row=mysqli_fetch_array($query)){
    $id=$row['id'];
    $sql = "UPDATE students SET id=$number WHERE id=$id";
    if($conn->query($sql) == TRUE){
        echo "Record RESET succesfully<br>";
    }
    $number++;
}
$sql = "ALTER TABLE students AUTO_INCREMENT =1";
if($conn->query($sql) == TRUE){
    echo "Record ALTER succesfully";
}else{
    echo"Error ALTER record: " . $conn->error;
} 
?>

