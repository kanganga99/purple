 


<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
 </head>
    <body class="sb-nav-fixed">
       
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h3 class="mt-4">Welcome</h3>
                  
                        <div class="row">
                  
                  <div class="card mb-4">
                   
                      <div class="card-body">
                      <div class="container">
    <button type="button" class="btn btn-primary"   onclick="location.href='http:/recent/assignment.php'">
  Add New
</button>

<button type="button" class="btn btn-primary" name="viewall"  onclick="location.href='http:/recent/viewall.php'" allign="top-right">
  Viewall
</button>


</div>


</div>

<!-- Modal -->

  </div>
</div>
    <table class="table table-hover text-center" id="studentsall">
  <thead class="table-light">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Studentname</th>
      <th scope="col">StudentID</th>
      <th scope="col">Phonenumber</th>
      <th scope="col">Location</th>
      <th scope="col">Religion</th>
      <th scope="col">Uploads</th>
      <th scope="col">Medical</th>
      <th scope="col">Training</th>
      <th scope="col">Passport</th>
      <th scope="col">Goodconduct</th>
      <th scope="col">Expenses</th>
    </tr>
  </thead>
  <tbody>
      <?php
      include "../config/db.php";
     //pag
     $results_per_page = 10;
     $query = "SELECT * FROM students  ";
     $result= mysqli_query($conn, $query);
     $number_of_result = mysqli_num_rows($result); 
     $number_of_page = ceil ($number_of_result / $results_per_page);  
     if (!isset ($_GET['page']) ) {  
      $page = 1;  
     } else {  
      $page = $_GET['page'];  
     }  
     $page_first_result = ($page-1) * $results_per_page;  
     $query = "SELECT * FROM students LIMIT " . $page_first_result . ',' . $results_per_page;  
 $result = mysqli_query($conn, $query); 
     $id=1;
     while($row= mysqli_fetch_assoc($result)){
?>
 <tr>
      <td ><?php echo $row['id'] ?></td>
      <td ><?php echo $row['studentname'] ?></td>
      <td ><?php echo $row['studentid'] ?></td>
      <td ><?php echo $row['phonenumber'] ?></td>
      <td ><?php echo $row['location'] ?></td>
      <td> <?php echo $row['religion'] ?></td>
      <td><?php echo $row['uploads'] ?></td>
      <td><?php echo $row['medical'] ?></td>
      <td><?php echo $row['training'] ?></td>
      <td><?php echo $row['passport'] ?></td>
      <td><?php echo $row['goodconduct'] ?></td>
      <td><?php echo $row['expenses'] ?></td>
      <td>
        <a href ="edit_student.php?id=<?php echo $row['id'] ?>"><button type="button" class="btn btn-primary">edit</button></a>      
        <a href="delete_student.php?id=<?php echo $row['id'] ?>" class="link-dark"><i class="fa-solid fa-trash fs-5 "></i></a>
     
        </td>
    </tr>
<?php

     }
     
    //  for($page = 1; $page<= $number_of_page; $page++) {  
    //   echo '<a href = "students.php?page=' . $page . '">' . $page . ' </a>';  
    //  }  
     
      ?>
   
  </tbody>
  <script>
             $(document).ready(function() {
               $("#studentsall").DataTable();
             });
           </script>
</table>
</div>
                      </div>
                  </div>
              </div>
                </main>
              
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
		<script src="assets/js/main.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
 
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>

    </body>
</html>
  




<a href="edit_student.php?id=<?php echo $row['id'] ?>"><button type="button" class="btn btn-primary">edit</button></a>
<a href="delete_student.php?id=<?php echo $row['id'] ?>" class="link-dark"><i class="fa-solid fa-trash fs-5 "></i></a>