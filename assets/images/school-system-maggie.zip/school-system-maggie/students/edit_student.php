
<?php
include "../config/db.php";
if(isset($_POST['submit'])){
    $id = isset($_GET['id']) ? $_GET['id']: '';
    // $id = $_POST['id'];

    $studentname = $_POST['studentname'];
    $religion = $_POST['religion'];
    $phonenumber = $_POST['phonenumber'];
    $location = $_POST['location'];
    $studentid = $_POST['studentid'];
    //  $uploads = $_POST['uploads'];
    $medical = $_POST['medical'];
    $training = $_POST['training'];
    $passport = $_POST['passport'];
    $goodconduct = $_POST['goodconduct'];
    $expenses = $_POST['expenses'];

    $chk = "";
    foreach ($expenses as $chk1) {
      $chk .= $chk1 . ",";
    }
    $path = "/";
    $uploads = [];
    $countfiles = count($_FILES['uploads']['name']);
    for ($i = 0; $i < $countfiles; $i++) {
      $filename = $_FILES['uploads']['name'][$i];
      $targetfilepath = 'assets/images/'. $filename;
      echo $targetfilepath;
      // Upload file
      move_uploaded_file($_FILES['uploads']['tmp_name'][$i], $targetfilepath);
      //  array_push($uploads,$filename);
      $uploads[] = $targetfilepath;
      $uploads2 = json_encode($uploads);

    }
     $sql ="UPDATE students SET studentname='$studentname',religion='$religion',phonenumber='$phonenumber',location='$location',studentid='$studentid',
     uploads='$uploads2',medical='$medical',training='$training',passport='$passport',goodconduct='$goodconduct',expenses='$chk' WHERE id = '$id'";
     $result = mysqli_query($conn, $sql);
     if($result){
         header("Location: ./index.php?msg=Data updated");
     }
     else{
         echo "Failed:" . mysqli_error($conn);
     }
}
?>
 
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Students Expenses</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="../assets/css/add_student.css">
</head>
<body>
  <div class="container">
    <div class="m-4">
    <?php
    $id = isset($_GET['id']) ? $_GET['id']: '';

$sql = "SELECT * FROM students WHERE `id` = '$id' LIMIT 1";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)){ 
  $uploads0 = $row['uploads'];
  $uploads=json_decode($uploads0);
  
  ?>
      <form action="" method="POST" enctype="multipart/form-data">
        <section id="Form1">
          <h1>Student Info</h1>
          <div class="row">
            <div class="col">
              <label class="form-label" for="studentname">Student Name</label>
              <input type="text" name="studentname" id="inputStudentname" placeholder="Studentname" class="form-control" 
              value=" <?php echo $row['studentname'] ?>"required /><br>

            </div>
          </div>
          <label class="form-label" for="religion">Religion</label>
          <input type="text" name="religion" id="religion" placeholder="religion" class="form-control" 
              value=" <?php echo $row['religion'] ?>"required /><br>
          <label class="form-label" for="phonenumber">Phone Number</label>
          <input type="text" name="phonenumber" id="inputphonenumber" placeholder="phonenumber" class="form-control" 
              value=" <?php echo $row['phonenumber'] ?>"required /><br>
              <label class="form-label" for="location">Location</label>
          <input type="text" name="location" id="inputlocation" placeholder="location" class="form-control" 
              value=" <?php echo $row['location'] ?>"required /><br>
          <label class="form-label" for="studentid">Student ID</label>
          <input type="text" name="studentid" id="inputstudentid" placeholder="studentid" class="form-control" 
              value=" <?php echo $row['studentid'] ?>"required /><br>
          <p>Upload student's birth certificate and parent's national ID here</p>
          <input type="file" value="<?php echo $row['uploads'] ?>" name="uploads[]" id="uploads" multiple /><br><br>
          <div class="row">
            <?php foreach($uploads as $upload){
              ?>
              <div class="col-6">
              <img class="img-fluid" src="<?php echo $upload ?>" alt="" width="250px">
              </div>
              <?php
            }
            ?>
          </div>
          <button type="button" id="Next1" required >Next</button>
        </section>
        <section id="Form2">
          <h3>Medical</h3>
          
          <!--<div class="container mt-3"> -->
          <select class="form-select mb-3" name="medical">
            <option value="<?php echo $row['medical']; ?>">Major</option>
            <option value="<?php echo $row['medical']; ?>">Minor</option>
          </select>
          <h1>Training</h1>
          <!--<div class="container mt-3"> -->
          <select class="form-select mb-3" name="training">
            <option value="Completed">completed</option>
            <option selected value="Not yet">not completed</option>
          </select>
          <div class="btn-box justify-content-center">
            <button type="button" id="Back1">Back</button><br>
            <button type="button" id="Next2" required >Next</button>
        </section>
        <section id="Form3">
          <h1>Passport</h1>
          <select class="form-select mb-3" name="passport">
            <option value="Submitted">Submitted</option>
            <option selected value="Not submitted">Not submitted</option>
          </select>
          <h1>Good Conduct</h1>
          <!--<div class="container mt-3"> -->
          <select class="form-select mb-3" name="goodconduct">
            <option value="Applied">Applied</option>
            <option selected value="Had">Had</option>
          </select>
          <div class="btn-box justify-content-center">
            <button type="button" id="Back2">Back</button><br>
            <button type="button" id="Next3">Next</button>
        </section>
        <section id="Form4">
          <h1>Expenses</h1>
          <!--<div class="container mt-3"> -->
          <br><input type="checkbox" name="expenses[]" id="Fare" value="Fare">
          <label for="Fare">Fare</label><br>
          <br><input type="checkbox" name="expenses[]" id="Medical" value="Medical">
          <label for="Medical">Medical</label><br>
          <br><input type="checkbox" name="expenses[]" id="Training" value="Training">
          <label for="Training">Training</label><br>
          <br><input type="checkbox" name="expenses[]" id="Passport push payment" value="Passport push payment">
          <label for="Passport push payment">Passport push payment</label><br>
          <br><input type="checkbox" name="expenses[]" id="Birth cert application fee" value="Birth cert application fee">
          <label for="Birth cert application fee">Birth cert application fee</label><br>
          <br><input type="checkbox" name="expenses[]" id="Appointment fee" value="Appointment fee">
          <label for="Appointment fee">Appointment fee</label><br>
          <br><input type="checkbox" name="expenses[]" id="Good conduct payment" value="Good conduct payment">
          <label for="Good conduct payment">Good conduct payment</label><br>
          <div class="btn-box justify-content-center">
            <button type="button" id="Back3">Back</button>
            <button type="submit" name="submit">Submit</button>
          </div>
        </section>
    </div>
    </form>
    <?php
}
?>
    <dvi class="step-row">
      <!--form step indicator adds a line at the top of each form-->
      <div id="progress"></div>
      <!--ensures it is divided into equal parts for instance in this case it will be 360/6=60px because it has 6 steps that is 6forms divide 360 by the number of steps or forms you have-->
      <div class="step-col"><small>Step 1</small></div>
      <div class="step-col"><small>Step 2</small></div>
      <div class="step-col"><small>Step 3</small></div>
      <div class="step-col"><small>Step 4</small></div>

    </dvi>

  </div>
  <script>
    var Form1 = document.getElementById("Form1");
    var Form2 = document.getElementById("Form2");
    var Form3 = document.getElementById("Form3");
    var Form4 = document.getElementById("Form4");

    var Next1 = document.getElementById("Next1");
    var Next2 = document.getElementById("Next2");
    var Next3 = document.getElementById("Next3");
    var Back1 = document.getElementById("Back1");
    var Back2 = document.getElementById("Back2");
    var Back3 = document.getElementById("Back3");
    

    var progress = document.getElementById("progress"); //makes the progress button move

    Next1.onclick = function() {
      Form1.style.left = "-450px";
      Form2.style.left = "120px";
      progress.style.width = "300px";
    }
    Back1.onclick = function() {
      Form1.style.left = "60px";
      Form2.style.left = "750px";
      progress.style.width = "120px";
    }
    Next2.onclick = function() {
      Form2.style.left = "-450px";
      Form3.style.left = "60px";
      progress.style.width = "460px";
    }
    Back2.onclick = function() {
      Form2.style.left = "60px";
      Form3.style.left = "750px";
      progress.style.width = "290px";
    }
    Next3.onclick = function() {
      Form3.style.left = "-450px";
      Form4.style.left = "60px";
      progress.style.width = "660px";
    }
    Back3.onclick = function() {
      Form3.style.left = "60px";
      Form4.style.left = "750px";
      progress.style.width = "460px";
    }
    
  </script>
</body>

</html>
  
