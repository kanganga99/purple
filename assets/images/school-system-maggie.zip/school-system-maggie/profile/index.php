<?php
include '../includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
    <body class="sb-nav-fixed">
       
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h3 class="mt-4">Welcome back <?php  echo $_SESSION ['username']?></h3>

                  
                        <div class="row">
                  
                  <div class="card mb-4">
                   
                      <div class="card-body">
                      <div class="container">
                     
                                        </div>
                  </div>
              </div>
                </main>
              
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
		<script src="../assets/js/main.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
 
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>

    </body>

</html>
