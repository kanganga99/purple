<?php
session_start(); 

include "config/db.php";

if (isset($_POST['username']) && isset($_POST['password'])) {

    function validate($data){

       $data = trim($data);

       $data = stripslashes($data);

       $data = htmlspecialchars($data);

       return $data;

    }

    $username = validate($_POST['username']);

    $password = validate($_POST['password']);

    if (empty($username)) {
        echo 'input your username';
        

    }else if(empty($password)){
        echo 'input your password';

    }else{

        $sql = "SELECT * FROM admins WHERE username='$username' AND password='$password'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if ($row['username'] === $username && $row['password'] === $password) {

                echo "Logged in!";

                $_SESSION['username'] = $row['username'];

                $_SESSION['id'] = $row['id'];

                header("Location: admin/index.php");

                exit();

            }else{

              echo 'invalid credentials';

            }

        }else{

            echo 'invaliddata';


        }

    }

}else{

    echo 'invalid  information';


}