<?php
$con = mysqli_connect("localhost","root","","schoolmanagement");
define('BASE_URL', 'http://localhost/recent/');
/*$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'schoolmanagement';

$con = mysqli_connect($servername, $username, $password, $dbname);

if(!$con){
    die("There was an error");
}*/
 

?>
