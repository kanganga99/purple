
<?php
include "../config/db_con.php";
if (isset($_POST['submit'])) {
  $studentname = $_POST["studentname"];
  $religion = $_POST["religion"];
  $phonenumber = $_POST["phonenumber"];
  $studentid = $_POST["studentid"];
  $medical = $_POST["medical"];
  $training = $_POST["training"];
  $passport = $_POST["passport"];
  $goodconduct = $_POST["goodconduct"];
  $expenses = $_POST['expenses'];
  $chk = "";
  foreach ($expenses as $chk1) {
    $chk .= $chk1 . ",";
  }
  $path = "/";
  $uploads = [];
  $countfiles = count($_FILES['uploads']['name']);
  for ($i = 0; $i < $countfiles; $i++) {
    $filename = $_FILES['uploads']['name'][$i];
    $targetfilepath = $path . $filename;
    echo $targetfilepath;
    // Upload file
    move_uploaded_file($_FILES['uploads']['tmp_name'][$i], $targetfilepath);
    //  array_push($uploads,$filename);
    $uploads[] = $targetfilepath;
    $uploads2 = json_encode($uploads);
  }
  $result = mysqli_query($con, "insert into students(studentname,religion,phonenumber,studentid,medical,training,passport,goodconduct,uploads,expenses)
       values('$studentname','$religion','$phonenumber',' $studentid','$medical','$training','$passport','$goodconduct','$uploads2','$chk')");
  if ($result === TRUE) {
    echo "<script>setTimeout(\"location.href = 'http://localhost/recent/students.php';\",1500);</script>";
    echo "inserted successfully";
  } else {
    echo "not inserted";
  }
}
?>
<?php


$sql=mysqli_query($con,"SELECT uploads FROM students ORDER BY id DESC LIMIT 1");
while($row=mysqli_fetch_array($sql)){
    $uploads=$row['uploads'];
    $uploads2=json_decode($uploads);
?>
<div>
    <ul>
        <?php
        foreach($uploads2 as $up){
            ?>
            <li><?php echo $up ?></li>
            <?php
        } 
        ?>
    </ul>
    <?php
    echo "student added successfully";
    header("../students.php");
    
    
    ?>
</div>
<?php
}

?>
<!-- 
header('Refresh:5; url=login6.php');
echo 'Please Log In First';


/include "config/connections.php";


$path = "uploads/";
$photos=[];
$countfiles = count($_FILES['photos']['name']);
for($i=0;$i<$countfiles;$i++){ $filename=$_FILES['photos']['name'][$i]; $targetfilepath=$path.$filename; echo $targetfilepath; // Upload file move_uploaded_file($_FILES['photos']['tmp_name'][$i],$targetfilepath); // array_push($photos,$filename); $photos[]=$targetfilepath; $photos2=json_encode($photos); } $sql=mysqli_query($con,"INSERT INTO photos(photos) VALUES ('$photos2')"); if($sql){ echo "success" ; } else{ echo "failed" ; } ?>


  FETCHING DATA FROM DB

  include 'config/connections.php';

  $sql=mysqli_query($con,"SELECT * FROM photos ORDER BY id DESC LIMIT 1");
  while($row=mysqli_fetch_array($sql)){
  $photos=$row['photos'];
  $photos2=json_decode($photos);
  ?> -->
<!-- <div>
    <ul>
        <//?php
        foreach ($photos2 as $ph) {
        ?>
            <li><//?php echo $ph ?></li>
            <//?php
          }
            ?>
    </ul>
    //<//?php echo $photos2['2'] ?>
</div> -->
<!-- } -->