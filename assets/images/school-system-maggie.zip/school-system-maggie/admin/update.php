<?php
include 'config.php';
$schoolname = $schoolocation = $id = '';
$schoolname_err = $location_err = '';

if(isset($_POST['schoolname']) && !empty($_POST['shoolname'])){
    $id = $_POST['id'];
    //schoolname
    $input_schoolname = trim($_POST['schoolname']);
    if(empty($input_schoolname)){
        $schoolname_err = "Please enter a name";
    }else{
        $schoolname = $input_name;
    }
//location
$input_location = trim($_POST['location']);
if(empty($input_location)){
    $schoolname_err = "Please enter location";
}else{
    $schoollocation = $input_location;
}
if(empty($schoolname_err) && empty($location_err)){
    $sql = "UPDATE schools SET schoolname=?, location=? WHERE id=?";

}
if($stmt= mysqli_prepare($conn, $sql)){
    mysqli_stmt_bind_param($stmt, $param_schoolname, $param_location);
    $param_schoolname = $schoolname;
    $param_location = $location;
}
if(mysqli_stmt_execute($stmt)){
    //updated successfully
    header("location: index.php");
    exit();
} else{
    echo "Oops! Something went wrong. Please try again later.";
}
mysqli_stmt_close($stmt);
}


else{

    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    
        $id =  trim($_GET["id"]);

        $sql = "SELECT * FROM schools WHERE id = ?";
        if($stmt = mysqli_prepare($link, $sql)){
          mysqli_stmt_bind_param($stmt, "i", $param_id);
            
           $param_id = $id;
            
          if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                 $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
 
                    $schoolname = $row["schoolname"];
                    $location = $row["location"];
              } else{
                   header("#");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        mysqli_stmt_close($stmt);
        
        mysqli_close($link);
    }  else{
      header("#");
        exit();
    }
}




?>