
<?php
   include "../config/db.php";

if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $check_duplicate_username ="SELECT username FROM admins WHERE username= '$username' ";
    $result = mysqli_query($conn , $check_duplicate_username);
    $count = mysqli_num_rows($result);
    if($count > 0){
        echo "<script>alert('username already exist'); window.username.href='./index.php';</script>";

    return false;
    }
    
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    
  $sql ="INSERT INTO `admins`(`id`, `username`, `password`, `email`) VALUES (NULL,'$username','$password','$email')";
     $result = mysqli_query($conn, $sql);
     if($result){
         header("Location: index.php");
     }
     else{
         echo "Failed:" . mysqli_error($conn);
     }
}
?>

