<?php
include '../includes/header.php';
if (isset($_GET['msg'])) {
  $msg = $_GET['msg'];
  echo '  <div class="alert alert-warning alert-dismissible fade show" role="alert">
    ' . $msg . '
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
?>

<!DOCTYPE html>
<html lang="en">
<body class="sb-nav-fixed">
  </div>
  <div id="layoutSidenav_content">
    <main>
      <div class="container-fluid px-4">
        <div class="row">
          <div class="card mb-4">
            <div class="card-body">
              <div class="container">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                  Add New
                </button>
                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="container d-flex justify-content-center">
                          <form action="add_admin.php" method="post" style="width:50vw; min-width:300px;">
                            <div class="row mb-3">
                              <div class="col">
                                <label class="form-label">User name</label>
                                <input type="text" class="form-control" name="username" placeholder="username">
                              </div>
                              <div class="mb-3 ">
                                <label class="form-label">Email</label>
                                <input type="text" class="form-control" name="email" placeholder="email address">
                              </div>
                              <div class="mb-3 ">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" placeholder="password">
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              <div>
                                <button type="submit" class="btn btn-primary" name="submit">Save</button>
                              </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <table class="table tb ">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Username</th>
              <th scope="col">email</th>
              <th scope="col">password</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // $id = isset($_GET['id']) ? $_GET['id'] : '';
            $mysqli = $conn;
            $sql = "SELECT * FROM admins ";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($result)) { 
              $id_no=$row['id'];
              ?>
              <tr>
                <th scope="row"><?php echo $row['id'] ?></th>
                <td><?php echo $row['username'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['password'] ?></td>
                <td>
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#edit_Modal<?php echo $row['id'] ?>">
                    edit
                  </button>
                </td>
                <div class="modal fade" id="edit_Modal<?php echo $row['id'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">edit admin</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body"> 
                      <input type="hidden" name="id" class="form-control" value=" <?php echo $row['id'] ?>"><br>                        
                        <input type="text" name="username" class="form-control" value=" <?php echo $row['username'] ?>"><br>
                        <input type="text" name="email" class="form-control" value="<?php echo $row['email']; ?>"><br>
                        <input type="text" name="password" class="form-control" value="<?php echo $row['password']; ?>">
                      </div>
                      <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <div>
                            <button type="submit" class="btn btn-primary" name="submit">Save</button>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
                </form>
                <td>
                  <a href="delete_admin.php?id=<?php echo $row['id'] ?>" class="link-dark"><button type="button" class="btn btn-outline-danger">Delete</button>
                  </a>
                </td>
              </tr>
            <?php
            }
            ?>
          </tbody>
        </table>
      </div>
  </div>
  </div>
  </div>
  </main>
  </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  <script src="../assets/js/main.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
</body>
</html>

