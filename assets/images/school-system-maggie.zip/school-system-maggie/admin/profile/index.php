<?php 
include 'includes/header.php';

   include "../config/db.php";
   if (isset($_SESSION['username']) && isset($_SESSION['id'])) {   ?>
	<?php if ($_SESSION['role'] == 'admin') {?>
		<?=$_SESSION['name']?>
	
		<?php include '../members.php';
                 if (mysqli_num_rows($res) > 0) {?>
				 <?php }?>
      	<?php }else { ?>
			<?=$_SESSION['name']?>
		
			<?php } ?>
			<?php }else{
	header("Location: ../index.php");
} ?>

<!DOCTYPE html>
<html lang="en">
    <body class="sb-nav-fixed">
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h3 class="mt-4"></h3>
                     
                          
                         
                        </div>
                      
                </main>
              
            </div>
       
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
		<script src="assets/js/main.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
 
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>

    </body>
</html>
