<?php  

if (isset($_SESSION['username']) && isset($_SESSION['id']) && isset($_SESSION['id'])) {
    
    $sql = "SELECT * FROM admins ORDER BY id ASC";
    $res = mysqli_query($conn, $sql);
}else{
	header("Location: logout.php");
} 
