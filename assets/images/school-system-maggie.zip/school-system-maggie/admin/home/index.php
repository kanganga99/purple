
<?php
include '../includes/header.php';
if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    echo '  <div class="alert alert-warning alert-dismissible fade show" role="alert">
    ' . $msg . '
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}


$conn = new mysqli($servername, $username, $password, $dbname);
$sql = "SELECT * FROM admins";
$sql2 = "SELECT * FROM users";
$sql3 = "SELECT * FROM schools";
$sql4 = "SELECT * FROM students";

//users
$resultusers = mysqli_query($conn, $sql2);
$rowcountusers = mysqli_num_rows($resultusers);
//admins
$resultadmins = mysqli_query($conn, $sql);
$rowcountadmins = mysqli_num_rows($resultadmins);
//schools
$resultschools = mysqli_query($conn, $sql3);
$rowcountschools = mysqli_num_rows($resultschools);
//students
$resultstudents = mysqli_query($conn, $sql4);
$rowcountstudents = mysqli_num_rows($resultstudents);

?>

<!DOCTYPE html>
<html lang="en">
<style>
    .color1 {
        background-color: #D1D1D1 ;
    }

    .color2 {
        background-color:#90E0EF;
    }

    .color3 {
        background-color: #68A7AD;
    }

    .color4 {
        background-color: #99C4C8;
    }
</style>

<body class="sb-nav-fixed">
    </div>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h3 class="mt-4">Welcome</h3>
                <div class="row">
                    <div class="col-xl-3 col-md-6">

                        <div class="card  numberofshool  text-black mb-4">
                            <div class="color1">
                                <div class="card-body"><?php echo "Number of schools: " . $rowcountschools; ?></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="../schools/"></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">


                            <div class="card text-black mb-4">
                            <div class="color2">

                                <div class="card-body"><?php echo "Number of students: " . $rowcountstudents; ?></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="../students/"></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                            <div class="card  text-white mb-4">
                            <div class="color3">

                                <div class="card-body"><?php echo "Number of users: " . $rowcountusers; ?></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="../users/"></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                            <div class="card text-white mb-4">
                            <div class="color4">

                                <div class="card-body"><?php echo "Number of admins: " . $rowcountadmins; ?></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="../admins/"></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </main>

    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../assets/js/main.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>

</body>

</html>

