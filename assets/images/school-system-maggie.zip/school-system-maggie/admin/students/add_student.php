<?php
include "../config/db.php";
if (isset($_POST['submit'])) {
  $studentname = $_POST["studentname"];
  $religion = $_POST["religion"];
  $phonenumber = $_POST["phonenumber"];
  $location = $_POST["location"];
  $studentid = $_POST["studentid"];
  $medical = $_POST["medical"];
  $training = $_POST["training"];
  $passport = $_POST["passport"];
  $goodconduct = $_POST["goodconduct"];
  $checkbox1 = $_POST['expenses'];
  $chk = "";
  foreach ($checkbox1 as $chk1) {
    $chk .= $chk1 . ",";
  }
  $path = "/";
  $uploads = [];
  $countfiles = count($_FILES['uploads']['name']);
  for ($i = 0; $i < $countfiles; $i++) {
    $filename = $_FILES['uploads']['name'][$i];
    $targetfilepath = '../assets/images/' . $filename;
    echo $targetfilepath;
    // Upload file
    move_uploaded_file($_FILES['uploads']['tmp_name'][$i], $targetfilepath);
    //  array_push($uploads,$filename);
    $uploads[] = $targetfilepath;
    $uploads2 = json_encode($uploads);
  }
  $result = mysqli_query($conn, "insert into students(studentname,religion,phonenumber,location,studentid,medical,training,passport,goodconduct,uploads,expenses)
       values('$studentname','$religion','$phonenumber','$location','$studentid','$medical','$training','$passport','$goodconduct','$uploads2','$chk')");
  if ($result === TRUE) {
    header("Location: ./index.php?msg=added successfully");
  } else {
    echo "Not added";
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Students Expenses</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="../assets/css/add_student.css">
</head>

<body>
  <div class="container">
    <div class="m-4">
      <form action="" method="POST" enctype="multipart/form-data">
        <section id="Form1">
          <h1>Student Info</h1>
          <div class="row">
            <div class="col">
              <label class="form-label" for="studentname">Student Name</label>
              <input type="studentname" class="form-control" id="inputStudentname" placeholder="Studentname" name="studentname" required>
            </div>
          </div>
          <label class="form-label" for="inputreligion">Religion</label>
          <input type="religion" class="form-control" id="inputreligion" placeholder="religion" name="religion">
          <label class="form-label" for="inputphonenumber">Phone Number</label>
          <input type="phonenumber" class="form-control" id="inputphonenumber" placeholder="phonenumber" name="phonenumber" required>
          <label class="form-label" for="inputlocation">Location</label>
          <input type="location" class="form-control" id="inputlocation" placeholder="location" name="location" required>
          <label class="form-label" for="inputid">Student ID</label>
          <input type="ID" class="form-control" id="inputstudenid" placeholder="Student ID" name="studentid">
          <p>Upload student's birth certificate and parent's national ID here</p>
          <input type="file" name="uploads[]" id="uploads" multiple /><br><br>
          <button type="button" id="Next1">Next</button>
        </section>
        <section id="Form2">
          <h4>Medical</h4>
          <!--<div class="container mt-3"> -->
          <select class="form-select mb-3" name="medical">
            <option value="Major">Major</option>
            <option selected value="Minor">Minor</option>
          </select><br>
          <h4>Training</h4>
          <!--<div class="container mt-3"> -->
          <select class="form-select mb-3" name="training">
            <option value="Completed">completed</option>
            <option selected value="Not yet">not completed</option>
          </select><br>
          <div class="btn-box justify-content-center">
            <br><button type="button" id="Back1">Back</button><br>
            <button type="button" id="Next2">Next</button>
        </section>
        <section id="Form3">
          <h4>Passport</h4>
          <select class="form-select mb-3" name="passport">
            <option value="Submitted">Submitted</option>
            <option selected value="Not submitted">Not submitted</option>
          </select><br>
          <h4>Good Conduct</h4>
          <!--<div class="container mt-3"> -->
          <select class="form-select mb-3" name="goodconduct">
            <option value="Applied">Applied</option>
            <option selected value="Had">Had</option>
          </select><br>
          <div class="btn-box justify-content-center">
            <br><button type="button" id="Back2">Back</button><br>
            <button type="button" id="Next3">Next</button>
        </section>
        <section id="Form4">
          <h4>Expenses</h4>
          <!--<div class="container mt-3"> -->
          <br><input type="checkbox" name="expenses[]" id="Fare" value="Fare">
          <label for="Fare">Fare</label><br>
          <br><input type="checkbox" name="expenses[]" id="Medical" value="Medical">
          <label for="Medical">Medical</label><br>
          <br><input type="checkbox" name="expenses[]" id="Training" value="Training">
          <label for="Training">Training</label><br>
          <br><input type="checkbox" name="expenses[]" id="Passport push payment" value="Passport push payment">
          <label for="Passport push payment">Passport push payment</label><br>
          <br><input type="checkbox" name="expenses[]" id="Birth cert application fee" value="Birth cert application fee">
          <label for="Birth cert application fee">Birth cert application fee</label><br>
          <br><input type="checkbox" name="expenses[]" id="Appointment fee" value="Appointment fee">
          <label for="Appointment fee">Appointment fee</label><br>
          <br><input type="checkbox" name="expenses[]" id="Good conduct payment" value="Good conduct payment">
          <label for="Good conduct payment">Good conduct payment</label><br><br>
          <div class="btn-box justify-content-center">
            <br><br><button type="button" id="Back3">Back</button>
            <button type="submit" name="submit">Submit</button>
          </div>
        </section>
    </div>
    </form>
    <dvi class="step-row">
      <!--form step indicator adds a line at the top of each form-->
      <div id="progress"></div>
      <!--ensures it is divided into equal parts for instance in this case it will be 360/6=60px because it has 6 steps that is 6forms divide 360 by the number of steps or forms you have-->
      <div class="step-col"><small>Step 1</small></div>
      <div class="step-col"><small>Step 2</small></div>
      <div class="step-col"><small>Step 3</small></div>
      <div class="step-col"><small>Step 4</small></div>
    </dvi>

  </div>
  <script>
    var Form1 = document.getElementById("Form1");
    var Form2 = document.getElementById("Form2");
    var Form3 = document.getElementById("Form3");
    var Form4 = document.getElementById("Form4");

    var Next1 = document.getElementById("Next1");
    var Next2 = document.getElementById("Next2");
    var Next3 = document.getElementById("Next3");
    var Back1 = document.getElementById("Back1");
    var Back2 = document.getElementById("Back2");
    var Back3 = document.getElementById("Back3");


    var progress = document.getElementById("progress"); //makes the progress button move

    Next1.onclick = function() {
      Form1.style.left = "-450px";
      Form2.style.left = "60px";
      progress.style.width = "300px";
    }
    Back1.onclick = function() {
      Form1.style.left = "60px";
      Form2.style.left = "750px";
      progress.style.width = "120px";
    }
    Next2.onclick = function() {
      Form2.style.left = "-450px";
      Form3.style.left = "60px";
      progress.style.width = "460px";
    }
    Back2.onclick = function() {
      Form2.style.left = "60px";
      Form3.style.left = "750px";
      progress.style.width = "290px";
    }
    Next3.onclick = function() {
      Form3.style.left = "-450px";
      Form4.style.left = "60px";
      progress.style.width = "660px";
    }
    Back3.onclick = function() {
      Form3.style.left = "60px";
      Form4.style.left = "750px";
      progress.style.width = "460px";
    }
  </script>
</body>

</html>