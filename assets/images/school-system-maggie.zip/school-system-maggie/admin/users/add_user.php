<?php
include "../config/db.php";

if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $location = $_POST['location'];
    $role = $_POST['role'];
    $location = isset($location) ? $location : '';
    if(isset($_POST['location'])){
        $location = $_POST['location'];
      }

    $sql ="INSERT INTO `users`(`id`, `username`, `password`, `email`, `location`, `role`) VALUES (NULL,'$username','$password','$email','$location','$role')";
     $result = mysqli_query($conn, $sql);
     if($result){
         header("Location: index.php?msg=New user added");
     }
     else{
      echo "Failed:" . mysqli_error($conn);
  }
    
}
?>




