
<?php
// include '../includes/header.php';
?>
<?php
session_start();
if (!isset($_SESSION['username']) && !isset($_SESSION['id'])) {   ?>
	<!DOCTYPE html>
	<html>

	<head>
		<title>login</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	</head>
	<style>
		.bing {
			background-color: #d1e0e0;
		}
	</style>

	<body>
		<div class="bing">
			<div class="container d-flex justify-content-center align-items-center " style="min-height: 100vh  ">
				<form class="border shadow p-3 rounded" style="background: #f0f5f5; " action="login.php" method="post" style="width: 450px;">

					<h3 class="text-center p-3">Welcome</h3>
					<p>To login, enter your registered username and password</p>
					<?php if (isset($_GET['error'])) { ?>
						<div class="alert alert-danger" role="alert">
							<?= $_GET['error'] ?>
						</div>
					<?php } ?>
					<div class="mb-3">
						<label for="username" class="form-label">User name</label>
						<input type="text" class="form-control" Placeholder="Enter username" name="username" id="username">
					</div>
					<div class="mb-3">
						<label for="password" class="form-label">Password</label>
						<input type="password" name="password" Placeholder="Enter password" class="form-control" id="password">
					</div>


					<button type="submit" class="btn btn-primary">LOGIN</button>
				</form>
			</div>
		</div>
	</body>

	</html>
<?php } else {
	header("Location: home/");
} ?>

