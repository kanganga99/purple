<?php
   include "../config/db.php";
if(isset($_POST['submit'])){
    $schoolname = $_POST['schoolname'];
    $location = $_POST['location'];
    $check_duplicate_location ="SELECT location FROM schools WHERE location= '$location' ";
    $result = mysqli_query($conn , $check_duplicate_location);
    $count = mysqli_num_rows($result);
    if($count > 0){
        echo "<script>alert('location already exist'); window.location.href='./index.php';</script>";
    return false;
    }
  $sql ="INSERT INTO `schools`(`id`, `schoolname`, `location`) VALUES (NULL,'$schoolname','$location')";
     $result = mysqli_query($conn, $sql);
     if($result){
         header("Location: index.php?msg=New school added");
     }
     else{
         echo "Failed:" . mysqli_error($conn);
     }
}
?>

