<?php
session_start();
include_once("../config/db.php");
if (isset($_POST['editbtn'])) {
	$id = $_POST['id'];
    $schoolname = $_POST['schoolname'];
    $location = $_POST['location'];
    $sql ="UPDATE `schools` SET `schoolname`='$schoolname',`location`='$location' WHERE id='$id'  ";
    $result = mysqli_query($conn, $sql);
    if($result){
        header("Location: index.php");
    }
    else{
        echo "Failed:" . mysqli_error($conn);
    }
}
