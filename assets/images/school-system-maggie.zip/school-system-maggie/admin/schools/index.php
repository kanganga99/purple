<?php
include '../includes/header.php';
if (isset($_GET['msg'])) {
  $msg = $_GET['msg'];
  echo '  <div class="alert alert-warning alert-dismissible fade show" role="alert">
    ' . $msg . '
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- MDBootstrap Datatables  -->
<link href="css/addons/datatables2.min.css" rel="stylesheet">
<link href="css/addons/datatables2.min.css" rel="stylesheet">

<body class="sb-nav-fixed">


  </div>
  <div id="layoutSidenav_content">
    <main>
      <div class="container-fluid px-4">
        <h4 class="mt-4">List of schools</h4>

        <div class="row">

          <div class="card mb-4">

            <div class="card-body">
              <div class="container">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                  Add New
                </button>
                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="container d-flex justify-content-center">
                          <form action="add_school.php" method="post" style="width:50vw; min-width:300px;">
                            <div class="row mb-3">
                              <div class="col">
                                <label class="form-label">School name</label>
                                <input type="text" class="form-control" name="schoolname" placeholder="schoolname">
                              </div>
                              <div class="mb-3 ">
                                <label class="form-label">location</label>
                                <input type="text" class="form-control" name="location" placeholder="location">
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              <div>
                                <button type="submit" class="btn btn-primary" name="submit">Save</button>
                              </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <table class="table table-hover text-center" id="schools">
          <thead class="table-light">
            <tr>
              <th scope="col">ID</th>
              <th scope="col">School Name</th>
              <th scope="col">Location</th>

              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            include "../config/db.php";
            //pag
            $results_per_page = 10;
            $query = "SELECT * FROM schools  ";
            $result = mysqli_query($conn, $query);
            $number_of_result = mysqli_num_rows($result);
            $number_of_page = ceil($number_of_result / $results_per_page);
            if (!isset($_GET['page'])) {
              $page = 1;
            } else {
              $page = $_GET['page'];
            }
            $page_first_result = ($page - 1) * $results_per_page;
            $query = "SELECT *FROM schools LIMIT " . $page_first_result . ',' . $results_per_page;
            $result = mysqli_query($conn, $query);
            $id = 1;
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
              <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $row['schoolname'] ?></td>
                <td><?php echo $row['location'] ?></td>
                <td>
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#edit_Modal<?php echo $row['id'] ?>">
                    edit
                  </button>
                  <form action="edit_school.php" method="post">
                    <div class="modal fade" id="edit_Modal<?php echo $row['id'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">edit school</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            <label for="id">ID: <?php echo $row['id']; ?></label>
                            <input type="text" id="id" name="id" value="<?php echo $row['id']; ?>" style="display:none">
                            <input type="text" name="schoolname" class="form-control" value=" <?php echo $row['schoolname'] ?>"><br>
                            <input type="text" name="location" class="form-control" value="<?php echo $row['location']; ?>">
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="editbtn" id="editbtn" class="btn btn-primary">update</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                  <a href="delete_school.php?id=<?php echo $row['id'] ?>" class="link-dark"><i class="fa-solid fa-trash fs-5 "></i></a>
                </td>
              </tr>
            <?php
            }
            // for ($page = 1; $page <= $number_of_page; $page++) {
            //   echo '<a href = "index.php?page=' . $page . '">' . $page . ' </a>';
            // }
            ?>
          </tbody>
          <script>
            $("#schools").DataTable();
          </script>
        </table>
      </div>
  </div>
  </div>
  </div>
  </main>
  </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  <script src="../assets/js/main.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
</body>

</html>
