<?php 
include '../includes/header.php';
$conn = new mysqli($servername, $username, $password, $dbname);

if (isset($_GET['location']) && $_GET['location'] != "") {
    $location1  = $_GET['location'];
   } else {
    $location1  = $_SESSION['location'];
   }
$sql = "SELECT  * FROM students WHERE location='$location1'";

$resultstudents=mysqli_query($conn,$sql);
$rowcountstudents=mysqli_num_rows($resultstudents);
  ?>
	<?php if (isset($_SESSION['location'])) : ?>
<!DOCTYPE html>
<html lang="en">
    <body class="sb-nav-fixed">
            </div>
            <div id="layoutSidenav_content">
                <main>

                

                    <div class="container-fluid px-4">
                        <h3 class="mt-4"><?php echo $_SESSION['location']; ?></h3>
                        <div class="row">
                           
                            <div class="col-xl-3 col-md-6">

                                <style>
                                      .card{
                                        background-color: #81C9D7;
                                    }
                                </style>
                                <div class="card  text-white mb-4">

                                    <div class="card-body"><?php  echo "Number of students: ".$rowcountstudents; ?></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="../students/">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>

                         
                        </div>
                      
                </main>
              
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
		<script src="../assets/js/main.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
 
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>

    </body>
</html>
<?php endif ?> 
